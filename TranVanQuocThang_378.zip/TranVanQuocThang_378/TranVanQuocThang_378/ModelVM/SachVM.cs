﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TranVanQuocThang_378.ModelVM {
    internal class SachVM {
        public string Masach { get; set; }
        public string Tensach { get; set; }
        public string Theloai { get; set; }
        public string Namxb { get; set; }
        public string Manxb { get; set; }

    }
}
