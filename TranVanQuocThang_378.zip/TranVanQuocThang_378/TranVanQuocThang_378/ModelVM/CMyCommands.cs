﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace TranVanQuocThang_378.ModelVM {
    internal class CMyCommands {
        public static RoutedUICommand lenhThem = new RoutedUICommand();
    }
}
